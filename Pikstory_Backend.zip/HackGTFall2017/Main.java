package com.get.main;

import java.util.Arrays;

public class Main {
    

    public static void main(String[] args) {
        System.out.println(returnThings());
    }

    public static String returnThings() {
        try {
            String[] values = JsonParser.parse(ImageToText.getTextFromFile("/sdcard/Android/data/cn.easyar.samples.unity.helloar/files/Screenshot.png"), "text");
            String[] images = JsonParser.parse(BingWebSearch.searchWeb(values[0]), "contentUrl");
            String imageURL = images[0];
            imageURL = imageURL.replace("\\","");
            return (imageURL);
        } catch (Exception e) {
            return e.getMessage();
        }
        
    }
}
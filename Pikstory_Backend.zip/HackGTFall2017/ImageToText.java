package com.get.main;

// // This sample uses the Apache HTTP client from HTTP Components (http://hc.apache.org/httpcomponents-client-ga/)
import java.io.File;
import java.io.FileInputStream;
import java.net.URI;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

public class ImageToText {

    public static String getTextFromFile(String imageFileName) throws Exception{
        HttpClient httpclient = HttpClients.createDefault();

        URIBuilder builder = new URIBuilder("https://westcentralus.api.cognitive.microsoft.com/vision/v1.0/ocr");

        builder.setParameter("language", "unk");
        builder.setParameter("detectOrientation ", "true");

        /*
        URI uri = builder.build();
        HttpPost request = new HttpPost(uri);
        request.setHeader("Content-Type", "application/json");
        request.setHeader("Ocp-Apim-Subscription-Key", "8028a317b0e5418ba7b9c27fb627d7d0");


        // Request body
        String url = "https://digitalsynopsis.com/wp-content/uploads/2016/03/hidden-meaning-logos-word-as-image-calligrams-2.jpg";
        StringEntity reqEntity = new StringEntity("{\"url\":\"" + url + "\"}");
        request.setEntity(reqEntity);
        */

            URI uri = builder.build();
        HttpPost request = new HttpPost(uri);
        request.setHeader("Content-Type", "application/octet-stream");
        request.setHeader("Ocp-Apim-Subscription-Key", "8028a317b0e5418ba7b9c27fb627d7d0");


        // Request body
        File file = new File(imageFileName);
        request.setEntity(new InputStreamEntity(
            new FileInputStream(file), -1, ContentType.APPLICATION_OCTET_STREAM));


        HttpResponse response = httpclient.execute(request);
        HttpEntity entity = response.getEntity();

        return EntityUtils.toString(entity);
    }
}

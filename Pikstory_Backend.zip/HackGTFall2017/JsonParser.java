package com.get.main;

import java.util.ArrayList;
import java.util.List;
import java.util.HashSet;
import java.util.Set;

public class JsonParser {
    public static String[] parse(String json, String key) {
        Set<String> values = new HashSet<>();
        String toLookFor = "\"" + key + "\":";
        while(json.contains(toLookFor)) {
            json = json.substring(json.indexOf(toLookFor) + toLookFor.length()).trim();
            json = json.substring(1);
            values.add(json.substring(0, json.indexOf("\"")));
        }
        List<String> v = new ArrayList<>(values);
        String[] toReturn = new String[v.size()];
        for (int i = 0; i < toReturn.length; i++) {
            toReturn[i] = v.get(i);
        }
        return toReturn;
    }
}